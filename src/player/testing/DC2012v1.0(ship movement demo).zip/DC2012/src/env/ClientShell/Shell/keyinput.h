#ifndef KEYINPUT_H
#define KEYINPUT_H

class keyInput
{
public:
    keyInput();
};

#endif // KEYINPUT_H
