#ifndef LANDTILE_H
#define LANDTILE_H

#include "tile.h"

class LandTile : public Tile
{
    public:
        LandTile(const Point& point);
        void setGraphic();

};

#endif // LANDTILE_H
