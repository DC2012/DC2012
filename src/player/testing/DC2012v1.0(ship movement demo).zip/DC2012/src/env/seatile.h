#ifndef SEATILE_H
#define SEATILE_H

#include "tile.h"

class SeaTile : public Tile
{
    public:
        SeaTile(const Point& position);
        void setGraphic();
};

#endif // SEATILE_H
