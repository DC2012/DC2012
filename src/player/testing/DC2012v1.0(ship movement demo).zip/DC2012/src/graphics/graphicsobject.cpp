#include "graphicsobject.h"
    GraphicsObject::GraphicsObject() {
    }

