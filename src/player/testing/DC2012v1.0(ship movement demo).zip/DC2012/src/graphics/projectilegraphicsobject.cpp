#include "projectilegraphicsobject.h"

    ProjectileGraphicsObject::ProjectileGraphicsObject(Point position)
    {
        position_ = position;
        //initGraphics();
    }
