#include "Player.h"
using namespace std;

Player::Player()
{
}

void Player::updateplayer()
{
    //send data to server to be processes and sent to other Players

    //receive new data from server

    //redraw with new data
}


