#include "GameObjectStationary.h"

void GameObjectStationary::print(std::ostream& os)const
{
	GameObject::print(os);
}